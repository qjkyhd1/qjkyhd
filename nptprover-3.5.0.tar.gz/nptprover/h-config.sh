#!/usr/bin/env bash

source h-manifest.conf

conf=""
conf+="ACCOUNT=\"$CUSTOM_TEMPLATE\""$'\n'
conf+="CUSTOM_URL=\"$CUSTOM_URL\""$'\n'
conf+="CUSTOM_USER_CONFIG=\"$CUSTOM_USER_CONFIG\""$'\n'

echo "$conf" > $CUSTOM_CONFIG_FILENAME